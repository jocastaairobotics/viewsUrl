from django.contrib import admin
from django.urls import path
from . import views

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('', views.main, name="main"),
#     path('free/', views.FreeClass, name="free"),
#     path('buy/', views.FreeClass, name="buy"),
#     path('list/', views.List),
# ]