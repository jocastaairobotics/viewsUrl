$("#techSeed").mouseover(function() {$(this).html("TechSeed Education")});
$("#techSeed").mouseout(function() {$(this).html("TechSeed")});

