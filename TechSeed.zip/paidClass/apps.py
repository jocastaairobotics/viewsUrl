from django.apps import AppConfig


class PaidclassConfig(AppConfig):
    name = 'paidClass'
