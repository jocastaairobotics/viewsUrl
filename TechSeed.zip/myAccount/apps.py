from django.apps import AppConfig


class MyaccountConfig(AppConfig):
    name = 'myAccount'
