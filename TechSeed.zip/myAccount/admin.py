from django.contrib import admin
from .models import newUser

# Register your models here.
admin.site.register(newUser)