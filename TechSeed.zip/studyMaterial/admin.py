from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Universitie)
admin.site.register(Department)
admin.site.register(Subject)
admin.site.register(Pre_Q_Paper)
admin.site.register(Gate)
admin.site.register(Indian_Engineering_Services)