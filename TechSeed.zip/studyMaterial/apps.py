from django.apps import AppConfig


class StudymaterialConfig(AppConfig):
    name = 'studyMaterial'
