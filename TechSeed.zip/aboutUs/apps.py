from django.apps import AppConfig


class AboutusConfig(AppConfig):
    name = 'aboutUs'
